import { useEffect, useMemo, useState } from "react";
import { ArrowDownRight, Compass, Mic, Moon, Sun } from "lucide-react";
import { HERO_IMAGE, PONIDZIE_TOWNS } from "./data/ponidzieData";
import { VoiceStory, fetchStories } from "./services/storyStorage";
import {
  TownEntry,
  deleteTownEntry,
  fetchTownEntries,
} from "./services/townEntriesStorage";
import PonidzieMap from "./components/PonidzieMap";
import TownMonographSection from "./components/TownMonographSection";
import VoiceStoryStudio from "./components/VoiceStoryStudio";
import NetlifyGuideModal from "./components/NetlifyGuideModal";

export default function App() {
  const [selectedTownId, setSelectedTownId] = useState<string>("busko-zdroj");
  const [studioTownId, setStudioTownId] = useState<string>("busko-zdroj");
  const [stories, setStories] = useState<VoiceStory[]>([]);
  const [townEntries, setTownEntries] = useState<TownEntry[]>([]);
  const [isLoadingStories, setIsLoadingStories] = useState<boolean>(true);
  const [heroImageFailed, setHeroImageFailed] = useState<boolean>(false);
  const [isNetlifyModalOpen, setIsNetlifyModalOpen] = useState<boolean>(false);
  const [isDark, setIsDark] = useState<boolean>(() => {
    if (typeof document === "undefined") return false;
    return document.documentElement.classList.contains("dark");
  });

  useEffect(() => {
    let active = true;
    Promise.all([fetchStories(), fetchTownEntries()])
      .then(([loadedStories, loadedEntries]) => {
        if (active) {
          setStories(loadedStories);
          setTownEntries(loadedEntries);
        }
      })
      .finally(() => {
        if (active) setIsLoadingStories(false);
      });
    return () => {
      active = false;
    };
  }, []);

  const toggleTheme = () => {
    const next = !isDark;
    setIsDark(next);
    document.documentElement.classList.toggle("dark", next);
    try {
      localStorage.setItem("ponidzie_theme", next ? "dark" : "light");
    } catch {
      // Ignore storage error
    }
  };

  const storyCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    for (const story of stories) {
      counts[story.townId] = (counts[story.townId] || 0) + 1;
    }
    return counts;
  }, [stories]);

  const handleRecordForTown = (townId: string) => {
    setStudioTownId(townId);
    const el = document.getElementById("opowiesci");
    if (el) {
      el.scrollIntoView({ behavior: "smooth" });
    }
  };

  const handleDeleteEntry = async (id: string) => {
    await deleteTownEntry(id);
    setTownEntries((prev) => prev.filter((item) => item.id !== id));
  };

  return (
    <div className="min-h-screen bg-[#F8F7F4] text-[#1C1917] dark:bg-[#131311] dark:text-[#F2F0EB] flex flex-col transition-colors duration-200">
      {/* Top Bar Contract: strictly 1 row, 3 zones */}
      <header className="sticky top-0 z-40 bg-[#F8F7F4]/95 dark:bg-[#131311]/95 backdrop-blur-sm border-b border-[#E5E2DC] dark:border-[#2B2A24]">
        <div className="max-w-7xl mx-auto px-6 lg:px-10 h-16 flex items-center justify-between gap-8">
          <a
            href="#kraina"
            className="font-serif text-lg sm:text-xl font-semibold tracking-tight text-[#1C1917] dark:text-[#F2F0EB] whitespace-nowrap shrink-0"
          >
            Przewodnik po Ponidziu
          </a>

          <nav
            aria-label="Nawigacja główna"
            className="hidden md:flex items-center gap-7 text-sm font-medium text-[#57534E] dark:text-[#A8A29E]"
          >
            <a
              href="#kraina"
              className="hover:text-[#1C1917] dark:hover:text-[#F2F0EB] transition-colors whitespace-nowrap shrink-0"
            >
              Kraina
            </a>
            <a
              href="#mapa"
              className="hover:text-[#1C1917] dark:hover:text-[#F2F0EB] transition-colors whitespace-nowrap shrink-0"
            >
              Mapa Nidy
            </a>
            <a
              href="#miejscowosci"
              className="hover:text-[#1C1917] dark:hover:text-[#F2F0EB] transition-colors whitespace-nowrap shrink-0"
            >
              Miejscowości
            </a>
            <a
              href="#opowiesci"
              className="hover:text-[#1C1917] dark:hover:text-[#F2F0EB] transition-colors whitespace-nowrap shrink-0"
            >
              Głosy i Opowieści
            </a>
          </nav>

          <div className="flex items-center shrink-0">
            <a
              href="#opowiesci"
              className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-[#1E4D3B] dark:bg-[#2A6F55] text-white text-xs sm:text-sm font-medium hover:bg-[#173B2D] dark:hover:bg-[#235C46] transition-colors whitespace-nowrap shrink-0"
            >
              <Mic className="w-3.5 h-3.5" />
              <span>Dodaj opowieść</span>
            </a>
          </div>
        </div>
      </header>

      <main className="flex-1">
        {/* Editorial Hero Section */}
        <section
          id="kraina"
          className="pt-10 pb-16 lg:pt-14 lg:pb-24 border-b border-[#E5E2DC] dark:border-[#2B2A24]"
        >
          <div className="max-w-7xl mx-auto px-6 lg:px-10">
            {/* Utility strip with Light/Dark theme switch */}
            <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
              <p className="text-xs uppercase tracking-[0.18em] text-[#57534E] dark:text-[#A8A29E] font-medium">
                Dolina Nidy · Świętokrzyskie · Stolica regionu: Busko-Zdrój
              </p>
              <button
                type="button"
                onClick={toggleTheme}
                aria-label={isDark ? "Przełącz na tryb jasny" : "Przełącz na tryb ciemny"}
                className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg border border-[#D6D3CB] dark:border-[#3A3932] bg-white dark:bg-[#1B1B18] text-xs font-medium text-[#1C1917] dark:text-[#F2F0EB] hover:bg-[#F2F0EB] dark:hover:bg-[#262520] transition-colors whitespace-nowrap shrink-0"
              >
                {isDark ? (
                  <>
                    <Sun className="w-3.5 h-3.5 text-[#FBBF24]" />
                    <span>Tryb jasny</span>
                  </>
                ) : (
                  <>
                    <Moon className="w-3.5 h-3.5 text-[#1E4D3B]" />
                    <span>Tryb ciemny</span>
                  </>
                )}
              </button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-end">
              <div className="lg:col-span-7">
                <h1 className="font-serif text-4xl sm:text-5xl lg:text-[3.75rem] font-semibold text-[#1C1917] dark:text-[#F2F0EB] leading-[1.08] tracking-tight text-balance">
                  Kraina białego kamienia, meandrów Nidy i ludzkiej pamięci
                </h1>
              </div>

              <div className="lg:col-span-5">
                <p className="text-base text-[#44403C] dark:text-[#D6D3CB] leading-relaxed max-w-prose mb-6">
                  Od uzdrowiskowego Buska-Zdroju — stolicy Ponidzia — przez Pińczów i Jędrzejów,
                  aż po piastowską Wiślicę, Solec-Zdrój i królewski Nowy Korczyn. Odkryj region
                  krok po kroku, dopisz własny rozdział do miejscowości lub nagraj opowieść głosem.
                </p>
                <div className="flex flex-wrap items-center gap-4">
                  <a
                    href="#miejscowosci"
                    className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-[#1C1917] dark:bg-[#F2F0EB] text-white dark:text-[#131311] text-sm font-medium hover:bg-[#292524] dark:hover:bg-[#E5E2DC] transition-colors whitespace-nowrap"
                  >
                    <span>Poznaj 6 miejscowości</span>
                    <ArrowDownRight className="w-4 h-4" />
                  </a>
                  <a
                    href="#dodaj-tresc-miasta"
                    className="text-sm font-medium text-[#1E4D3B] dark:text-[#6EE7B7] hover:underline whitespace-nowrap"
                  >
                    Dodaj treść do miasta
                  </a>
                </div>
              </div>
            </div>

            {/* Primary Focal Anchor Photography */}
            <figure className="mt-10 lg:mt-12">
              <div className="aspect-[16/9] w-full rounded-xl overflow-hidden bg-[#ECE9E2] dark:bg-[#262520] border border-[#E2DFD7] dark:border-[#2E2D28]">
                {heroImageFailed ? (
                  <div className="w-full h-full flex flex-col items-center justify-center p-10 text-center bg-gradient-to-br from-[#ECE9E2] to-[#DCD6CA] dark:from-[#262520] dark:to-[#1B1B18] text-[#57534E] dark:text-[#A8A29E]">
                    <Compass className="w-10 h-10 mb-3 text-[#1E4D3B] dark:text-[#6EE7B7]" />
                    <span className="font-serif text-2xl text-[#1C1917] dark:text-[#F2F0EB]">
                      Dolina rzeki Nidy · Ponidzie
                    </span>
                  </div>
                ) : (
                  <img
                    src={HERO_IMAGE}
                    alt="Poranna mgła nad rozlewiskami rzeki Nidy i zielonymi łąkami Ponidzia o wschodzie słońca"
                    referrerPolicy="no-referrer"
                    onError={() => setHeroImageFailed(true)}
                    className="w-full h-full object-cover"
                  />
                )}
              </div>
              <figcaption className="mt-3 flex flex-wrap items-center justify-between gap-2 text-xs text-[#57534E] dark:text-[#A8A29E]">
                <span className="font-serif italic">
                  Ryc. 01 — Rozlewiska Nidy o poranku, krajobraz Ponidzia.
                </span>
                <span className="font-mono text-[#78716C] dark:text-[#A8A29E]">50°28′N 20°43′E</span>
              </figcaption>
            </figure>

            {/* Clean 4-column Strip below Hero */}
            <div className="mt-12 pt-8 border-t border-[#E5E2DC] dark:border-[#2B2A24] grid grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8">
              <div>
                <p className="font-serif text-2xl sm:text-3xl font-semibold text-[#1C1917] dark:text-[#F2F0EB] tabular-nums">
                  {PONIDZIE_TOWNS.length}
                </p>
                <p className="text-xs sm:text-sm text-[#57534E] dark:text-[#A8A29E] mt-1">
                  Historyczne miejscowości na szlaku
                </p>
              </div>
              <div>
                <p className="font-serif text-2xl sm:text-3xl font-semibold text-[#1C1917] dark:text-[#F2F0EB] tabular-nums">
                  153 km
                </p>
                <p className="text-xs sm:text-sm text-[#57534E] dark:text-[#A8A29E] mt-1">
                  Długość biegu rzeki Nidy do Wisły
                </p>
              </div>
              <div>
                <p className="font-serif text-2xl sm:text-3xl font-semibold text-[#1C1917] dark:text-[#F2F0EB] tabular-nums">
                  {townEntries.length}
                </p>
                <p className="text-xs sm:text-sm text-[#57534E] dark:text-[#A8A29E] mt-1">
                  Dodane rozdziały do miast
                </p>
              </div>
              <div>
                <p className="font-serif text-2xl sm:text-3xl font-semibold text-[#1E4D3B] dark:text-[#6EE7B7] tabular-nums">
                  {stories.length}
                </p>
                <p className="text-xs sm:text-sm text-[#57534E] dark:text-[#A8A29E] mt-1">
                  Opowieści głosowych w archiwum
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Interactive Cartographic Trail Map */}
        <PonidzieMap
          selectedTownId={selectedTownId}
          onSelectTown={setSelectedTownId}
          onRecordForTown={handleRecordForTown}
          storyCounts={storyCounts}
          isDark={isDark}
        />

        {/* Six-Town Editorial Monograph Explorer + TownContentStudio */}
        <TownMonographSection
          selectedTownId={selectedTownId}
          onSelectTown={setSelectedTownId}
          onRecordForTown={handleRecordForTown}
          storyCounts={storyCounts}
          townEntries={townEntries}
          onEntryPublished={(entry) => setTownEntries((prev) => [entry, ...prev])}
          onDeleteEntry={handleDeleteEntry}
        />

        {/* Voice Recording, Upload & Automatic Transcription Archive */}
        <VoiceStoryStudio
          stories={stories}
          isLoadingStories={isLoadingStories}
          preselectedTownId={studioTownId}
          onStoriesChange={setStories}
        />
      </main>

      {/* Quiet Editorial Footer */}
      <footer className="border-t border-[#E5E2DC] dark:border-[#2B2A24] bg-[#F2F0EB] dark:bg-[#1A1A17]">
        <div className="max-w-7xl mx-auto px-6 lg:px-10 py-10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
          <div>
            <p className="font-serif text-lg font-semibold text-[#1C1917] dark:text-[#F2F0EB]">
              Przewodnik po Ponidziu
            </p>
            <p className="text-xs text-[#57534E] dark:text-[#A8A29E] mt-1">
              Busko-Zdrój · Pińczów · Wiślica · Jędrzejów · Nowy Korczyn · Solec-Zdrój
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-6 text-xs text-[#57534E] dark:text-[#A8A29E]">
            <a
              href="#mapa"
              className="hover:text-[#1C1917] dark:hover:text-[#F2F0EB] transition-colors"
            >
              Mapa szlaku
            </a>
            <a
              href="#miejscowosci"
              className="hover:text-[#1C1917] dark:hover:text-[#F2F0EB] transition-colors"
            >
              Miejscowości
            </a>
            <a
              href="#opowiesci"
              className="hover:text-[#1C1917] dark:hover:text-[#F2F0EB] transition-colors"
            >
              Dodaj opowieść
            </a>
            <button
              type="button"
              onClick={toggleTheme}
              className="hover:text-[#1C1917] dark:hover:text-[#F2F0EB] transition-colors"
            >
              {isDark ? "Tryb jasny" : "Tryb ciemny"}
            </button>
            <button
              type="button"
              onClick={() => setIsNetlifyModalOpen(true)}
              className="font-medium text-[#1E4D3B] dark:text-[#6EE7B7] hover:underline"
            >
              Konfiguracja w Netlify
            </button>
          </div>
        </div>
      </footer>

      <NetlifyGuideModal
        isOpen={isNetlifyModalOpen}
        onClose={() => setIsNetlifyModalOpen(false)}
      />
    </div>
  );
}

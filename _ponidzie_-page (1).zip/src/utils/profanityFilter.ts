const POLISH_PROFANITY_PATTERNS: RegExp[] = [
  /\bkurw[aąeęiyou]*\b/gi,
  /\bchuj[aąeęiuowy]*\b/gi,
  /\bhuj[aąeęiuowy]*\b/gi,
  /\bpierdol[aąeęiounyłśżź]*\b/gi,
  /\bpierdal[aąeęiounyłśżź]*\b/gi,
  /\bjeb[aąeęiounyłśżź]*\b/gi,
  /\bwyjeb[aąeęiounyłśżź]*\b/gi,
  /\bzajeb[aąeęiounyłśżź]*\b/gi,
  /\bpojeb[aąeęiounyłśżź]*\b/gi,
  /\bodjeb[aąeęiounyłśżź]*\b/gi,
  /\bskurw[aąeęiounyłśżź]*\b/gi,
  /\bkutas[aąeęiouwy]*\b/gi,
  /\bcip[aąeęiouy]*\b/gi,
  /\bpizd[aąeęiouy]*\b/gi,
  /\bdupa\b/gi,
  /\bdup[aąeęiyou]+\b/gi,
  /\bsuka\b/gi,
  /\bsuk[aąi]\b/gi,
  /\bsukinsyn[aąeęiouwy]*\b/gi,
  /\bcholera\b/gi,
  /\bcholer[aąeęny]*\b/gi,
  /\bgówn[aąeęiouy]+\b/gi,
  /\bgown[aąeęiouy]+\b/gi,
  /\bsra[ćcłlmnjwz]*\b/gi,
  /\bzesra[ćcłlmnjwz]*\b/gi,
  /\bobsra[ćcłlmnjwz]*\b/gi,
  /\bkurde\b/gi,
  /\bkretyn[aąeęiouwy]*\b/gi,
  /\bidiot[aąeęiouwy]*\b/gi,
  /\bdebili?\b/gi,
  /\bpedał[aąeęiouwy]*\b/gi,
  /\bpedal[aąeęiouwy]*\b/gi,
  /\bcwel[aąeęiouwy]*\b/gi,
  /\bfuck[a-z]*\b/gi,
  /\bshit[a-z]*\b/gi,
];

function maskWord(word: string): string {
  if (word.length <= 2) return "***";
  return `${word[0]}${"*".repeat(Math.max(2, word.length - 2))}${word[word.length - 1]}`;
}

export interface ProfanitySanitizeResult {
  cleanedText: string;
  replacedCount: number;
}

export function autoCorrectProfanity(input: string): ProfanitySanitizeResult {
  if (!input) {
    return { cleanedText: "", replacedCount: 0 };
  }

  let replacedCount = 0;
  let output = input;

  for (const pattern of POLISH_PROFANITY_PATTERNS) {
    output = output.replace(pattern, (match) => {
      replacedCount += 1;
      return maskWord(match);
    });
  }

  return {
    cleanedText: output,
    replacedCount,
  };
}

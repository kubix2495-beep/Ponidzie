import { FormEvent, useEffect, useState } from "react";
import { BookOpen, Check, Loader2, ShieldCheck } from "lucide-react";
import { PONIDZIE_TOWNS } from "../data/ponidzieData";
import { autoCorrectProfanity } from "../utils/profanityFilter";
import { TownEntry, saveTownEntry } from "../services/townEntriesStorage";

interface TownContentStudioProps {
  preselectedTownId: string;
  onEntryPublished: (entry: TownEntry) => void;
}

export default function TownContentStudio({
  preselectedTownId,
  onEntryPublished,
}: TownContentStudioProps) {
  const [headline, setHeadline] = useState("");
  const [summary, setSummary] = useState("");
  const [story, setStory] = useState("");
  const [townId, setTownId] = useState(preselectedTownId || "busko-zdroj");
  const [author, setAuthor] = useState("");

  const [moderationNotice, setModerationNotice] = useState<string>("");
  const [errorMessage, setErrorMessage] = useState<string>("");
  const [successMessage, setSuccessMessage] = useState<string>("");
  const [isPublishing, setIsPublishing] = useState(false);

  useEffect(() => {
    if (preselectedTownId) {
      setTownId(preselectedTownId);
    }
  }, [preselectedTownId]);

  const runStoryAutoCorrection = (rawText: string): string => {
    const res = autoCorrectProfanity(rawText);
    if (res.replacedCount > 0) {
      setModerationNotice(
        `Auto-korekta oczyściła ${res.replacedCount} ${
          res.replacedCount === 1 ? "niecenzuralne słowo" : "niecenzuralne słowa"
        } w treści opowieści.`
      );
    }
    return res.cleanedText;
  };

  const handleStoryBlur = () => {
    const cleaned = runStoryAutoCorrection(story);
    if (cleaned !== story) {
      setStory(cleaned);
    }
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setErrorMessage("");
    setSuccessMessage("");
    setModerationNotice("");

    const cleanHeadline = autoCorrectProfanity(headline.trim());
    const cleanSummary = autoCorrectProfanity(summary.trim());
    const cleanStory = autoCorrectProfanity(story.trim());
    const cleanAuthor = autoCorrectProfanity(author.trim());

    const totalCleaned =
      cleanHeadline.replacedCount +
      cleanSummary.replacedCount +
      cleanStory.replacedCount +
      cleanAuthor.replacedCount;

    if (
      !cleanHeadline.cleanedText ||
      !cleanSummary.cleanedText ||
      !cleanStory.cleanedText ||
      !cleanAuthor.cleanedText
    ) {
      setErrorMessage(
        "Uzupełnij wszystkie pola: nagłówek, o czym to opowiada, treść opowieści oraz imię lub nazwę autora."
      );
      return;
    }

    const selectedTown = PONIDZIE_TOWNS.find((t) => t.id === townId) ?? PONIDZIE_TOWNS[0];
    setIsPublishing(true);

    try {
      const saved = await saveTownEntry({
        headline: cleanHeadline.cleanedText,
        summary: cleanSummary.cleanedText,
        story: cleanStory.cleanedText,
        townId: selectedTown.id,
        townName: selectedTown.name,
        author: cleanAuthor.cleanedText,
      });

      onEntryPublished(saved);
      setHeadline("");
      setSummary("");
      setStory("");
      setAuthor("");

      if (totalCleaned > 0) {
        setModerationNotice(
          `Auto-korekta automatycznie oczyściła ${totalCleaned} nieodpowiednich słów przed publikacją.`
        );
      }
      setSuccessMessage(
        `Wpis został opublikowany i przypisany bezpośrednio do miejscowości ${selectedTown.name}.`
      );
    } catch (err) {
      setErrorMessage(
        err instanceof Error ? err.message : "Nie udało się zapisać wpisu w przewodniku."
      );
    } finally {
      setIsPublishing(false);
    }
  };

  return (
    <div
      id="dodaj-tresc-miasta"
      className="mt-14 bg-white dark:bg-[#1B1B18] border border-[#E5E2DC] dark:border-[#2E2D28] rounded-xl p-6 sm:p-10"
    >
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-6 border-b border-[#ECE9E2] dark:border-[#2E2D28]">
        <div>
          <p className="text-xs uppercase tracking-[0.16em] text-[#1E4D3B] dark:text-[#6EE7B7] font-medium mb-2">
            Współtworzenie przewodnika
          </p>
          <h3 className="font-serif text-2xl sm:text-3xl font-semibold text-[#1C1917] dark:text-[#F2F0EB]">
            Dodaj nową treść do wybranego miasta
          </h3>
        </div>
        <div className="inline-flex items-center gap-2 text-xs text-[#57534E] dark:text-[#A8A29E]">
          <ShieldCheck className="w-4 h-4 text-[#1E4D3B] dark:text-[#6EE7B7] shrink-0" />
          <span>Wbudowana auto-korekta niecenzuralnych słów</span>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="mt-6 space-y-5 max-w-3xl">
        {/* Krok 1: Nagłówek */}
        <div>
          <label
            htmlFor="entry-headline"
            className="block text-xs uppercase tracking-[0.12em] text-[#57534E] dark:text-[#A8A29E] font-medium mb-2"
          >
            1. Nagłówek
          </label>
          <input
            id="entry-headline"
            type="text"
            value={headline}
            onChange={(e) => setHeadline(e.target.value)}
            placeholder="np. Stary dworzec kolejki wąskotorowej i letnie wyjazdy"
            className="w-full rounded-lg border border-[#D6D3CB] dark:border-[#3A3932] bg-[#FBFBF9] dark:bg-[#131311] px-4 py-2.5 text-sm text-[#1C1917] dark:text-[#F2F0EB] placeholder:text-[#A8A29E] dark:placeholder:text-[#78716C] focus:outline-none focus:ring-2 focus:ring-[#1E4D3B] dark:focus:ring-[#6EE7B7]"
          />
        </div>

        {/* Krok 2: O czym to opowiada */}
        <div>
          <label
            htmlFor="entry-summary"
            className="block text-xs uppercase tracking-[0.12em] text-[#57534E] dark:text-[#A8A29E] font-medium mb-2"
          >
            2. O czym to opowiada
          </label>
          <input
            id="entry-summary"
            type="text"
            value={summary}
            onChange={(e) => setSummary(e.target.value)}
            placeholder="np. Krótka historia o spacerach i ludziach spotykanych w parku w latach osiemdziesiątych"
            className="w-full rounded-lg border border-[#D6D3CB] dark:border-[#3A3932] bg-[#FBFBF9] dark:bg-[#131311] px-4 py-2.5 text-sm text-[#1C1917] dark:text-[#F2F0EB] placeholder:text-[#A8A29E] dark:placeholder:text-[#78716C] focus:outline-none focus:ring-2 focus:ring-[#1E4D3B] dark:focus:ring-[#6EE7B7]"
          />
        </div>

        {/* Krok 3: Sama opowieść z auto-korektą */}
        <div>
          <div className="flex items-center justify-between gap-2 mb-2">
            <label
              htmlFor="entry-story"
              className="text-xs uppercase tracking-[0.12em] text-[#57534E] dark:text-[#A8A29E] font-medium"
            >
              3. Sama opowieść
            </label>
            <button
              type="button"
              onClick={() => {
                const cleaned = runStoryAutoCorrection(story);
                setStory(cleaned);
              }}
              className="text-xs font-medium text-[#1E4D3B] dark:text-[#6EE7B7] hover:underline"
            >
              Sprawdź i oczyść tekst
            </button>
          </div>
          <textarea
            id="entry-story"
            rows={6}
            value={story}
            onChange={(e) => setStory(e.target.value)}
            onBlur={handleStoryBlur}
            placeholder="Napisz pełną treść rozdziału lub wspomnienia. Po opublikowaniu tekst pojawi się bezpośrednio w opisie wybranej miejscowości."
            className="w-full rounded-lg border border-[#D6D3CB] dark:border-[#3A3932] bg-[#FBFBF9] dark:bg-[#131311] px-4 py-3 text-sm text-[#1C1917] dark:text-[#F2F0EB] leading-relaxed placeholder:text-[#A8A29E] dark:placeholder:text-[#78716C] focus:outline-none focus:ring-2 focus:ring-[#1E4D3B] dark:focus:ring-[#6EE7B7]"
          />
        </div>

        {/* Krok 4 i 5: Miejscowość oraz Imię / nazwa autora */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label
              htmlFor="entry-town"
              className="block text-xs uppercase tracking-[0.12em] text-[#57534E] dark:text-[#A8A29E] font-medium mb-2"
            >
              4. Wybierz miejscowość
            </label>
            <select
              id="entry-town"
              value={townId}
              onChange={(e) => setTownId(e.target.value)}
              className="w-full rounded-lg border border-[#D6D3CB] dark:border-[#3A3932] bg-[#FBFBF9] dark:bg-[#131311] px-3.5 py-2.5 text-sm text-[#1C1917] dark:text-[#F2F0EB] focus:outline-none focus:ring-2 focus:ring-[#1E4D3B] dark:focus:ring-[#6EE7B7]"
            >
              {PONIDZIE_TOWNS.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label
              htmlFor="entry-author"
              className="block text-xs uppercase tracking-[0.12em] text-[#57534E] dark:text-[#A8A29E] font-medium mb-2"
            >
              5. Imię lub nazwa autora
            </label>
            <input
              id="entry-author"
              type="text"
              value={author}
              onChange={(e) => setAuthor(e.target.value)}
              placeholder="np. Tata, Marek z Buska"
              className="w-full rounded-lg border border-[#D6D3CB] dark:border-[#3A3932] bg-[#FBFBF9] dark:bg-[#131311] px-3.5 py-2.5 text-sm text-[#1C1917] dark:text-[#F2F0EB] placeholder:text-[#A8A29E] dark:placeholder:text-[#78716C] focus:outline-none focus:ring-2 focus:ring-[#1E4D3B] dark:focus:ring-[#6EE7B7]"
            />
          </div>
        </div>

        {moderationNotice && (
          <div className="rounded-lg border border-[#FCD34D] dark:border-[#92400E] bg-[#FFFBEB] dark:bg-[#451A03]/40 px-4 py-3 text-xs sm:text-sm text-[#92400E] dark:text-[#FDE68A]">
            {moderationNotice}
          </div>
        )}

        {errorMessage && (
          <div
            role="alert"
            className="rounded-lg border border-[#FCA5A5] dark:border-[#7F1D1D] bg-[#FEF2F2] dark:bg-[#450A0A]/50 px-4 py-3 text-xs sm:text-sm text-[#991B1B] dark:text-[#FECACA]"
          >
            {errorMessage}
          </div>
        )}

        {successMessage && (
          <div
            role="status"
            className="rounded-lg border border-[#BBF7D0] dark:border-[#166534] bg-[#F0FDF4] dark:bg-[#052E16]/50 px-4 py-3 text-xs sm:text-sm text-[#166534] dark:text-[#BBF7D0] flex items-center gap-2"
          >
            <Check className="w-4 h-4 shrink-0" />
            <span>{successMessage}</span>
          </div>
        )}

        <div className="pt-2">
          <button
            type="submit"
            disabled={isPublishing}
            className="inline-flex items-center gap-2 px-5 py-3 rounded-lg bg-[#1E4D3B] dark:bg-[#2A6F55] text-white text-sm font-medium hover:bg-[#173B2D] dark:hover:bg-[#235C46] disabled:opacity-50 transition-colors whitespace-nowrap"
          >
            {isPublishing ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Publikowanie wpisu...</span>
              </>
            ) : (
              <>
                <BookOpen className="w-4 h-4" />
                <span>6. Opublikuj w opisie miejscowości</span>
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
}

import { useState } from "react";
import { Compass, Mic, Trash2 } from "lucide-react";
import { PONIDZIE_TOWNS } from "../data/ponidzieData";
import { TownEntry } from "../services/townEntriesStorage";
import TownContentStudio from "./TownContentStudio";

interface TownMonographSectionProps {
  selectedTownId: string;
  onSelectTown: (townId: string) => void;
  onRecordForTown: (townId: string) => void;
  storyCounts: Record<string, number>;
  townEntries: TownEntry[];
  onEntryPublished: (entry: TownEntry) => void;
  onDeleteEntry: (id: string) => void;
}

function formatEntryDate(iso: string): string {
  try {
    return new Intl.DateTimeFormat("pl-PL", {
      day: "numeric",
      month: "long",
      year: "numeric",
    }).format(new Date(iso));
  } catch {
    return iso;
  }
}

export default function TownMonographSection({
  selectedTownId,
  onSelectTown,
  onRecordForTown,
  storyCounts,
  townEntries,
  onEntryPublished,
  onDeleteEntry,
}: TownMonographSectionProps) {
  const [failedImages, setFailedImages] = useState<Record<string, boolean>>({});
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const activeTown =
    PONIDZIE_TOWNS.find((t) => t.id === selectedTownId) ?? PONIDZIE_TOWNS[0];

  const entriesForActiveTown = townEntries.filter((e) => e.townId === activeTown.id);

  const markImageFailed = (key: string) => {
    setFailedImages((prev) => ({ ...prev, [key]: true }));
  };

  return (
    <section
      id="miejscowosci"
      className="py-20 lg:py-28 border-b border-[#E5E2DC] dark:border-[#2B2A24]"
    >
      <div className="max-w-7xl mx-auto px-6 lg:px-10">
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 mb-10">
          <div>
            <p className="text-xs uppercase tracking-[0.18em] text-[#57534E] dark:text-[#A8A29E] font-medium mb-3">
              02 · Monografie miejscowości
            </p>
            <h2 className="font-serif text-3xl sm:text-4xl font-semibold text-[#1C1917] dark:text-[#F2F0EB] tracking-tight text-balance">
              Przewodnik po sześciu punktach Ponidzia
            </h2>
          </div>

          <div
            role="tablist"
            aria-label="Wybierz miejscowość Ponidzia"
            className="flex flex-wrap items-center gap-1 p-1 bg-[#EFECE5] dark:bg-[#22211C] rounded-lg border border-[#E2DFD7] dark:border-[#323029]"
          >
            {PONIDZIE_TOWNS.map((town) => {
              const active = town.id === activeTown.id;
              return (
                <button
                  key={town.id}
                  role="tab"
                  type="button"
                  aria-selected={active}
                  onClick={() => onSelectTown(town.id)}
                  className={`px-3 py-2 text-xs sm:text-sm font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                    active
                      ? "bg-white dark:bg-[#131311] text-[#1C1917] dark:text-[#F2F0EB] shadow-xs"
                      : "text-[#57534E] dark:text-[#A8A29E] hover:text-[#1C1917] dark:hover:text-[#F2F0EB]"
                  }`}
                >
                  {town.name}
                </button>
              );
            })}
          </div>
        </div>

        {/* Active Town Detailed Monograph */}
        <article className="bg-white dark:bg-[#1B1B18] border border-[#E5E2DC] dark:border-[#2E2D28] rounded-xl p-6 sm:p-10 lg:p-12">
          <div className="flex flex-wrap items-center gap-3 text-xs text-[#57534E] dark:text-[#A8A29E] pb-6 border-b border-[#ECE9E2] dark:border-[#2E2D28]">
            <span className="font-mono tabular-nums uppercase tracking-wider">
              Rozdział {activeTown.index}
            </span>
            <span aria-hidden="true">·</span>
            <span className="font-medium text-[#1E4D3B] dark:text-[#6EE7B7]">
              {activeTown.subtitle}
            </span>
            <span aria-hidden="true">·</span>
            <span>{activeTown.regionNote}</span>
            <span aria-hidden="true">·</span>
            <span className="tabular-nums">
              Nagrane opowieści: {storyCounts[activeTown.id] || 0}
            </span>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 mt-8 items-start">
            <div className="lg:col-span-7">
              <h3 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-semibold text-[#1C1917] dark:text-[#F2F0EB] tracking-tight mb-6">
                {activeTown.name}
              </h3>

              <div className="space-y-5 max-w-prose text-[#292524] dark:text-[#E7E5E4] text-[15px] sm:text-base leading-[1.8]">
                <p className="editorial-drop-cap">{activeTown.editorialLead}</p>
                <p>{activeTown.editorialContinuation}</p>
              </div>

              {/* Community/Editorial Added Chapters seamlessly integrated into the town */}
              {entriesForActiveTown.length > 0 && (
                <div className="mt-10 pt-8 border-t border-[#ECE9E2] dark:border-[#2E2D28] space-y-8">
                  {entriesForActiveTown.map((entry) => (
                    <section key={entry.id} className="max-w-prose">
                      <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-[#78716C] dark:text-[#A8A29E] mb-2">
                        <div>
                          <span>{entry.author}</span>
                          <span aria-hidden="true"> · </span>
                          <span>{formatEntryDate(entry.createdAt)}</span>
                        </div>

                        {confirmDeleteId === entry.id ? (
                          <div className="flex items-center gap-2">
                            <button
                              type="button"
                              onClick={() => {
                                onDeleteEntry(entry.id);
                                setConfirmDeleteId(null);
                              }}
                              className="text-xs font-medium text-[#991B1B] dark:text-[#FCA5A5] hover:underline"
                            >
                              Potwierdź usunięcie
                            </button>
                            <button
                              type="button"
                              onClick={() => setConfirmDeleteId(null)}
                              className="text-xs hover:underline"
                            >
                              Anuluj
                            </button>
                          </div>
                        ) : (
                          <button
                            type="button"
                            aria-label={`Usuń wpis ${entry.headline}`}
                            onClick={() => setConfirmDeleteId(entry.id)}
                            className="p-1 rounded hover:bg-[#FEF2F2] dark:hover:bg-[#450A0A]/40 hover:text-[#991B1B] dark:hover:text-[#FCA5A5] transition-colors"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>

                      <h4 className="font-serif text-2xl font-semibold text-[#1C1917] dark:text-[#F2F0EB] mb-2">
                        {entry.headline}
                      </h4>
                      <p className="text-sm font-medium text-[#1E4D3B] dark:text-[#6EE7B7] mb-3 leading-relaxed">
                        {entry.summary}
                      </p>
                      <p className="text-[15px] sm:text-base text-[#292524] dark:text-[#E7E5E4] leading-[1.8] whitespace-pre-line">
                        {entry.story}
                      </p>
                    </section>
                  ))}
                </div>
              )}

              <blockquote className="my-8 py-6 border-y border-[#E5E2DC] dark:border-[#2E2D28]">
                <p className="font-serif italic text-xl sm:text-2xl text-[#1C1917] dark:text-[#F2F0EB] leading-relaxed">
                  „{activeTown.atmosphereQuote}”
                </p>
              </blockquote>

              <div className="pt-2">
                <p className="text-xs uppercase tracking-[0.16em] text-[#57534E] dark:text-[#A8A29E] font-medium mb-2">
                  Wskazówka na spacer
                </p>
                <p className="text-sm sm:text-[15px] text-[#44403C] dark:text-[#D6D3CB] leading-relaxed max-w-prose">
                  {activeTown.walkingTip}
                </p>
              </div>
            </div>

            <div className="lg:col-span-5 space-y-8">
              <figure>
                <div className="aspect-[4/3] w-full rounded-lg overflow-hidden bg-[#ECE9E2] dark:bg-[#262520] border border-[#E2DFD7] dark:border-[#323029]">
                  {failedImages[activeTown.id] ? (
                    <div className="w-full h-full flex flex-col items-center justify-center p-6 text-center bg-gradient-to-br from-[#EFECE5] to-[#E2DDD2] dark:from-[#262520] dark:to-[#1B1B18] text-[#57534E] dark:text-[#A8A29E]">
                      <Compass className="w-8 h-8 mb-3 text-[#1E4D3B] dark:text-[#6EE7B7]" />
                      <span className="font-serif text-lg text-[#1C1917] dark:text-[#F2F0EB]">
                        {activeTown.name}
                      </span>
                      <span className="text-xs mt-1">{activeTown.subtitle}</span>
                    </div>
                  ) : (
                    <img
                      src={activeTown.image}
                      alt={activeTown.imageAlt}
                      referrerPolicy="no-referrer"
                      onError={() => markImageFailed(activeTown.id)}
                      className="w-full h-full object-cover"
                    />
                  )}
                </div>
                <figcaption className="mt-2.5 font-serif italic text-xs text-[#57534E] dark:text-[#A8A29E]">
                  {activeTown.imageCaption}
                </figcaption>
              </figure>

              {activeTown.secondaryPhoto && (
                <figure>
                  <div className="aspect-[16/10] w-full rounded-lg overflow-hidden bg-[#ECE9E2] dark:bg-[#262520] border border-[#E2DFD7] dark:border-[#323029]">
                    {failedImages[`${activeTown.id}_sec`] ? (
                      <div className="w-full h-full flex flex-col items-center justify-center p-6 text-center bg-gradient-to-br from-[#EFECE5] to-[#E2DDD2] dark:from-[#262520] dark:to-[#1B1B18] text-[#57534E] dark:text-[#A8A29E]">
                        <Compass className="w-6 h-6 mb-2 text-[#1E4D3B] dark:text-[#6EE7B7]" />
                        <span className="text-xs">{activeTown.secondaryPhoto.caption}</span>
                      </div>
                    ) : (
                      <img
                        src={activeTown.secondaryPhoto.src}
                        alt={activeTown.secondaryPhoto.alt}
                        referrerPolicy="no-referrer"
                        onError={() => markImageFailed(`${activeTown.id}_sec`)}
                        className="w-full h-full object-cover"
                      />
                    )}
                  </div>
                  <figcaption className="mt-2 font-serif italic text-xs text-[#57534E] dark:text-[#A8A29E]">
                    {activeTown.secondaryPhoto.caption}
                  </figcaption>
                </figure>
              )}

              <div>
                <h4 className="text-xs uppercase tracking-[0.16em] text-[#57534E] dark:text-[#A8A29E] font-medium pb-3 border-b border-[#ECE9E2] dark:border-[#2E2D28]">
                  Warto zobaczyć w terenie
                </h4>
                <dl className="divide-y divide-[#ECE9E2] dark:divide-[#2E2D28]">
                  {activeTown.highlights.map((highlight) => (
                    <div key={highlight.name} className="py-3.5">
                      <dt className="flex flex-wrap items-baseline justify-between gap-2">
                        <span className="font-medium text-sm text-[#1C1917] dark:text-[#F2F0EB]">
                          {highlight.name}
                        </span>
                        <span className="font-mono text-xs text-[#78716C] dark:text-[#A8A29E] tabular-nums">
                          {highlight.era}
                        </span>
                      </dt>
                      <dd className="mt-1 text-xs sm:text-sm text-[#57534E] dark:text-[#A8A29E] leading-relaxed">
                        {highlight.description}
                      </dd>
                    </div>
                  ))}
                </dl>
              </div>

              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => onRecordForTown(activeTown.id)}
                  className="w-full inline-flex items-center justify-center gap-2 px-5 py-3 rounded-lg bg-[#1E4D3B] dark:bg-[#2A6F55] text-white text-sm font-medium hover:bg-[#173B2D] dark:hover:bg-[#235C46] transition-colors whitespace-nowrap"
                >
                  <Mic className="w-4 h-4" />
                  <span>Nagraj wspomnienie z: {activeTown.name}</span>
                </button>
              </div>
            </div>
          </div>
        </article>

        {/* Compact 6-town Editorial Directory */}
        <div className="mt-10 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {PONIDZIE_TOWNS.map((town) => {
            const isSelected = town.id === activeTown.id;
            return (
              <button
                key={town.id}
                type="button"
                onClick={() => onSelectTown(town.id)}
                className={`text-left p-6 rounded-xl border transition-colors ${
                  isSelected
                    ? "bg-[#1E4D3B] dark:bg-[#2A6F55] text-white border-[#1E4D3B] dark:border-[#2A6F55]"
                    : "bg-white dark:bg-[#1B1B18] text-[#1C1917] dark:text-[#F2F0EB] border-[#E5E2DC] dark:border-[#2E2D28] hover:border-[#B8B2A6] dark:hover:border-[#57534E]"
                }`}
              >
                <div
                  className={`flex items-center justify-between text-xs mb-3 tabular-nums ${
                    isSelected ? "text-white/75" : "text-[#78716C] dark:text-[#A8A29E]"
                  }`}
                >
                  <span className="font-mono">{town.index}</span>
                  <span>Opowieści: {storyCounts[town.id] || 0}</span>
                </div>
                <h3 className="font-serif text-xl font-semibold mb-1">{town.name}</h3>
                <p
                  className={`text-xs mb-3 ${
                    isSelected ? "text-white/80" : "text-[#1E4D3B] dark:text-[#6EE7B7]"
                  }`}
                >
                  {town.subtitle}
                </p>
                <p
                  className={`text-sm leading-relaxed line-clamp-2 ${
                    isSelected ? "text-white/90" : "text-[#57534E] dark:text-[#A8A29E]"
                  }`}
                >
                  {town.summary}
                </p>
              </button>
            );
          })}
        </div>

        {/* Panel do dodawania nowych treści do miast */}
        <TownContentStudio
          preselectedTownId={activeTown.id}
          onEntryPublished={(entry) => {
            onEntryPublished(entry);
            onSelectTown(entry.townId);
          }}
        />
      </div>
    </section>
  );
}

import { useState } from "react";
import { Loader2, X } from "lucide-react";

interface NetlifyGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function NetlifyGuideModal({ isOpen, onClose }: NetlifyGuideModalProps) {
  const [diagResult, setDiagResult] = useState<string>("");
  const [isChecking, setIsChecking] = useState<boolean>(false);

  if (!isOpen) return null;

  const checkFunctionStatus = async () => {
    setIsChecking(true);
    setDiagResult("");
    try {
      const res = await fetch("/api/transcribe", { method: "GET" });
      if (!res.ok) {
        setDiagResult(`Funkcja zwróciła kod HTTP ${res.status}.`);
      } else {
        const data = (await res.json()) as {
          ok?: boolean;
          hasKey?: boolean;
          keyFormat?: string;
        };
        if (data.hasKey) {
          setDiagResult(
            `Połączenie działa. Wykryto klucz GEMINI_API_KEY (format: ${data.keyFormat || "poprawny"}).`
          );
        } else {
          setDiagResult(
            "Funkcja działa, ale zmienna GEMINI_API_KEY nie jest ustawiona w Netlify."
          );
        }
      }
    } catch {
      setDiagResult(
        "Nie udało się połączyć z funkcją transkrypcji (na serwerze deweloperskim działa ścieżka POST)."
      );
    } finally {
      setIsChecking(false);
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="netlify-guide-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/55 backdrop-blur-[2px]"
      onClick={onClose}
    >
      <div
        className="bg-white dark:bg-[#1B1B18] border border-[#E5E2DC] dark:border-[#2E2D28] rounded-xl max-w-xl w-full p-6 sm:p-8 shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-4 pb-4 border-b border-[#ECE9E2] dark:border-[#2E2D28]">
          <div>
            <p className="text-xs uppercase tracking-[0.16em] text-[#1E4D3B] dark:text-[#6EE7B7] font-medium mb-1">
              Wdrożenie produkcyjne i klucze AQ.
            </p>
            <h3
              id="netlify-guide-title"
              className="font-serif text-2xl font-semibold text-[#1C1917] dark:text-[#F2F0EB]"
            >
              Konfiguracja w Netlify
            </h3>
          </div>
          <button
            type="button"
            aria-label="Zamknij okno"
            onClick={onClose}
            className="p-2 rounded-lg text-[#57534E] dark:text-[#A8A29E] hover:text-[#1C1917] dark:hover:text-[#F2F0EB] hover:bg-[#F4F2ED] dark:hover:bg-[#262520] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="mt-5 space-y-4 text-sm text-[#44403C] dark:text-[#D6D3CB] leading-relaxed">
          <p>
            Nowe klucze Google zaczynające się od{" "}
            <span className="font-mono text-[#1C1917] dark:text-[#F2F0EB]">AQ.</span> (zastępujące
            starsze klucze{" "}
            <span className="font-mono text-[#1C1917] dark:text-[#F2F0EB]">AIza...</span>) są już w
            pełni obsługiwane przez funkcję transkrypcji — zarówno w trybie Google AI Studio, jak i
            Vertex AI Express Mode.
          </p>

          <ol className="space-y-3 list-decimal list-inside">
            <li>
              W panelu Netlify wejdź w{" "}
              <strong>Site configuration → Environment variables</strong> i ustaw zmienną{" "}
              <span className="font-mono text-[#1C1917] dark:text-[#F2F0EB]">GEMINI_API_KEY</span>{" "}
              (wklej pełny klucz przyciskiem <strong>Copy key</strong> w Google AI Studio, bez
              spacji na końcu).
            </li>
            <li>
              Po zmianie zmiennych środowiskowych w Netlify kliknij{" "}
              <strong>Deploys → Trigger deploy → Clear cache and deploy site</strong>, aby funkcja
              serwerowa odświeżyła konfigurację.
            </li>
            <li>
              Pamiętaj, że Netlify ogranicza rozmiar pojedynczego żądania do ok. 4 MB — nagrania z
              mikrofonu są już automatycznie kompresowane, aby bez problemu mieścić się w tym
              limicie.
            </li>
          </ol>

          <div className="pt-2">
            <button
              type="button"
              onClick={checkFunctionStatus}
              disabled={isChecking}
              className="inline-flex items-center gap-2 px-3.5 py-2 rounded-lg border border-[#D6D3CB] dark:border-[#3A3932] text-xs font-medium text-[#1C1917] dark:text-[#F2F0EB] hover:bg-[#F4F2ED] dark:hover:bg-[#262520] transition-colors"
            >
              {isChecking && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
              <span>Sprawdź stan funkcji Netlify</span>
            </button>
            {diagResult && (
              <p className="mt-2.5 text-xs text-[#1E4D3B] dark:text-[#6EE7B7]">{diagResult}</p>
            )}
          </div>
        </div>

        <div className="mt-7 pt-5 border-t border-[#ECE9E2] dark:border-[#2E2D28] flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-lg bg-[#1E4D3B] dark:bg-[#2A6F55] text-white text-sm font-medium hover:bg-[#173B2D] dark:hover:bg-[#235C46] transition-colors"
          >
            Rozumiem
          </button>
        </div>
      </div>
    </div>
  );
}

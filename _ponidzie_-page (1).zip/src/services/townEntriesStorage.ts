export interface TownEntry {
  id: string;
  headline: string;
  summary: string;
  story: string;
  townId: string;
  townName: string;
  author: string;
  createdAt: string;
}

const DB_NAME = "ponidzie_town_entries_db";
const STORE_NAME = "entries";

function openEntriesDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, 1);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME, { keyPath: "id" });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

async function readLocalEntries(): Promise<TownEntry[]> {
  try {
    const db = await openEntriesDb();
    return await new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, "readonly");
      const req = tx.objectStore(STORE_NAME).getAll();
      req.onsuccess = () => {
        const items = (req.result as TownEntry[]) || [];
        items.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        resolve(items);
      };
      req.onerror = () => reject(req.error);
    });
  } catch {
    return [];
  }
}

async function writeLocalEntry(entry: TownEntry): Promise<void> {
  try {
    const db = await openEntriesDb();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, "readwrite");
      tx.objectStore(STORE_NAME).put(entry);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch {
    // Ignore IndexedDB quota errors
  }
}

async function removeLocalEntry(id: string): Promise<void> {
  try {
    const db = await openEntriesDb();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, "readwrite");
      tx.objectStore(STORE_NAME).delete(id);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch {
    // Ignore delete errors
  }
}

export async function fetchTownEntries(): Promise<TownEntry[]> {
  try {
    const response = await fetch("/api/town-entries");
    if (response.ok) {
      const data = (await response.json()) as { entries?: TownEntry[] };
      const serverEntries = Array.isArray(data.entries) ? data.entries : [];
      const localEntries = await readLocalEntries();
      const merged = new Map<string, TownEntry>();
      for (const s of serverEntries) merged.set(s.id, s);
      for (const l of localEntries) {
        if (!merged.has(l.id)) merged.set(l.id, l);
      }
      return Array.from(merged.values()).sort(
        (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      );
    }
  } catch {
    // Static Netlify fallback
  }
  return readLocalEntries();
}

export async function saveTownEntry(
  input: Omit<TownEntry, "id" | "createdAt">
): Promise<TownEntry> {
  try {
    const response = await fetch("/api/town-entries", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(input),
    });
    if (response.ok) {
      const data = (await response.json()) as { entry: TownEntry };
      await writeLocalEntry(data.entry);
      return data.entry;
    }
  } catch {
    // Static Netlify fallback
  }

  const localEntry: TownEntry = {
    ...input,
    id: `entry_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
    createdAt: new Date().toISOString(),
  };
  await writeLocalEntry(localEntry);
  return localEntry;
}

export async function deleteTownEntry(id: string): Promise<void> {
  await removeLocalEntry(id);
  try {
    await fetch(`/api/town-entries/${encodeURIComponent(id)}`, { method: "DELETE" });
  } catch {
    // Ignore on static host
  }
}

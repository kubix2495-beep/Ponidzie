import { GoogleGenAI } from "@google/genai";

interface TranscribeRequestBody {
  audioBase64?: string;
  mimeType?: string;
  townName?: string;
}

function normalizeAudioMimeType(rawMime?: string): string {
  if (!rawMime || typeof rawMime !== "string") {
    return "audio/webm";
  }
  const base = rawMime.split(";")[0].trim().toLowerCase();
  if (base === "audio/x-wav" || base === "audio/wave") return "audio/wav";
  if (base === "audio/x-m4a" || base === "audio/m4a") return "audio/mp4";
  return base || "audio/webm";
}

function buildPrompt(townName?: string): string {
  const contextHint = townName
    ? ` Nagranie dotyczy miejscowości lub okolic: ${townName} w regionie Ponidzia.`
    : "";
  return (
    "Dokonaj wiernej, starannej transkrypcji tego nagrania głosowego w języku polskim. " +
    "Zachowaj naturalną interpunkcję, podział na zdania i akapity oraz poprawne nazwy geograficzne Ponidzia " +
    "(Busko-Zdrój, Pińczów, Wiślica, Jędrzejów, Nowy Korczyn, Solec-Zdrój, Nida). " +
    "Zwróć wyłącznie sam tekst transkrypcji, bez żadnych dodatkowych komentarzy ani nagłówków." +
    contextHint
  );
}

async function runTranscriptionAttempt(
  apiKey: string,
  useVertexAi: boolean,
  model: string,
  mimeType: string,
  data: string,
  prompt: string
): Promise<string> {
  const ai = new GoogleGenAI({
    apiKey,
    ...(useVertexAi ? { vertexai: true } : {}),
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });

  const response = await ai.models.generateContent({
    model,
    contents: {
      parts: [
        {
          inlineData: {
            mimeType,
            data,
          },
        },
        { text: prompt },
      ],
    },
  });

  return (response.text ?? "").trim();
}

export default async function handler(req: Request): Promise<Response> {
  if (req.method === "GET") {
    const rawKey = (process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY || "").trim();
    return Response.json({
      ok: true,
      hasKey: Boolean(rawKey),
      keyFormat: rawKey.startsWith("AQ.")
        ? "AQ"
        : rawKey.startsWith("AIza")
        ? "AIza"
        : rawKey
        ? "custom"
        : "missing",
    });
  }

  if (req.method !== "POST") {
    return Response.json({ error: "Metoda niedozwolona. Użyj POST." }, { status: 405 });
  }

  const apiKey = (process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY || "").trim();
  if (!apiKey) {
    return Response.json(
      {
        error:
          "Brak klucza GEMINI_API_KEY w zmiennych środowiskowych Netlify (Site configuration → Environment variables).",
      },
      { status: 500 }
    );
  }

  try {
    const body = (await req.json()) as TranscribeRequestBody;
    const rawBase64 = body.audioBase64?.includes(",")
      ? body.audioBase64.split(",")[1]
      : body.audioBase64;

    if (!rawBase64 || rawBase64.trim().length < 16) {
      return Response.json({ error: "Brak danych audio do transkrypcji." }, { status: 400 });
    }

    const mimeType = normalizeAudioMimeType(body.mimeType);
    const prompt = buildPrompt(body.townName);

    const isAqKey = apiKey.startsWith("AQ.");
    // Try standard Gemini API first (supports both AIza and AI Studio AQ. keys),
    // and fall back to Vertex AI Express Mode (for Google Cloud AQ. keys) + public Gemini 2.5 Flash if 404/401.
    const attempts: Array<{ vertex: boolean; model: string }> = [
      { vertex: false, model: "gemini-3.5-transcribe" },
      { vertex: false, model: "gemini-2.5-flash" },
      ...(isAqKey
        ? [
            { vertex: true, model: "gemini-2.5-flash" },
            { vertex: true, model: "gemini-3.5-transcribe" },
          ]
        : []),
    ];

    let lastError: unknown = null;
    for (const attempt of attempts) {
      try {
        const transcript = await runTranscriptionAttempt(
          apiKey,
          attempt.vertex,
          attempt.model,
          mimeType,
          rawBase64,
          prompt
        );
        if (transcript) {
          return Response.json({ transcript });
        }
      } catch (err) {
        lastError = err;
      }
    }

    const detail = lastError instanceof Error ? lastError.message : "Nieznany błąd API Gemini.";
    return Response.json(
      {
        error: `Transkrypcja nie powiodła się (${detail}). Sprawdź poprawność klucza GEMINI_API_KEY w Netlify.`,
      },
      { status: 502 }
    );
  } catch (err) {
    const message = err instanceof Error ? err.message : "Błąd przetwarzania żądania audio.";
    return Response.json({ error: message }, { status: 500 });
  }
}

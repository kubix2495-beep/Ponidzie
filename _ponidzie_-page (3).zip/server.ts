import "dotenv/config";
import express from "express";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const DATA_DIR = path.resolve(__dirname, "data");
const STORIES_FILE = path.join(DATA_DIR, "stories.json");
const TOWN_ENTRIES_FILE = path.join(DATA_DIR, "town-entries.json");

interface StoredStory {
  id: string;
  title: string;
  author: string;
  townId: string;
  townName: string;
  note?: string;
  audioDataUrl: string;
  mimeType: string;
  durationSeconds: number;
  createdAt: string;
}

interface StoredTownEntry {
  id: string;
  headline: string;
  summary: string;
  story: string;
  townId: string;
  townName: string;
  author: string;
  createdAt: string;
}

function ensureDataFiles(): void {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  if (!fs.existsSync(STORIES_FILE)) {
    fs.writeFileSync(STORIES_FILE, JSON.stringify([], null, 2), "utf-8");
  }
  if (!fs.existsSync(TOWN_ENTRIES_FILE)) {
    fs.writeFileSync(TOWN_ENTRIES_FILE, JSON.stringify([], null, 2), "utf-8");
  }
}

function readJsonArray<T>(filePath: string): T[] {
  ensureDataFiles();
  try {
    const raw = fs.readFileSync(filePath, "utf-8");
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as T[]) : [];
  } catch {
    return [];
  }
}

function writeJsonArray<T>(filePath: string, data: T[]): void {
  ensureDataFiles();
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2), "utf-8");
}

function normalizeAudioMimeType(rawMime?: string): string {
  if (!rawMime || typeof rawMime !== "string") {
    return "audio/webm";
  }
  const base = rawMime.split(";")[0].trim().toLowerCase();
  if (base === "audio/x-wav" || base === "audio/wave") return "audio/wav";
  if (base === "audio/x-m4a" || base === "audio/m4a") return "audio/mp4";
  return base || "audio/webm";
}

async function startServer(): Promise<void> {
  const app = express();
  const port = Number(process.env.PORT) || 3000;
  const isProd = process.env.NODE_ENV === "production";

  app.use(express.json({ limit: "25mb" }));

  app.get("/api/health", (_req, res) => {
    res.json({ ok: true });
  });

  app.get("/api/stories", (_req, res) => {
    const stories = readJsonArray<StoredStory>(STORIES_FILE);
    res.json({ stories });
  });

  app.post("/api/stories", (req, res) => {
    const body = req.body as Partial<StoredStory>;
    if (!body.title?.trim() || !body.author?.trim() || !body.audioDataUrl) {
      res.status(400).json({ error: "Uzupełnij tytuł, autora oraz nagranie audio." });
      return;
    }

    const newStory: StoredStory = {
      id: `story_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      title: body.title.trim(),
      author: body.author.trim(),
      townId: body.townId || "ponidzie",
      townName: body.townName || "Całe Ponidzie",
      note: body.note?.trim() || "",
      audioDataUrl: body.audioDataUrl,
      mimeType: normalizeAudioMimeType(body.mimeType),
      durationSeconds: Number(body.durationSeconds) || 0,
      createdAt: new Date().toISOString(),
    };

    const existing = readJsonArray<StoredStory>(STORIES_FILE);
    writeJsonArray(STORIES_FILE, [newStory, ...existing]);
    res.status(201).json({ story: newStory });
  });

  app.delete("/api/stories/:id", (req, res) => {
    const { id } = req.params;
    const existing = readJsonArray<StoredStory>(STORIES_FILE);
    const filtered = existing.filter((item) => item.id !== id);
    if (filtered.length === existing.length) {
      res.status(404).json({ error: "Nie znaleziono opowieści." });
      return;
    }
    writeJsonArray(STORIES_FILE, filtered);
    res.json({ deleted: id });
  });

  app.get("/api/town-entries", (_req, res) => {
    const entries = readJsonArray<StoredTownEntry>(TOWN_ENTRIES_FILE);
    res.json({ entries });
  });

  app.post("/api/town-entries", (req, res) => {
    const body = req.body as Partial<StoredTownEntry>;
    if (
      !body.headline?.trim() ||
      !body.summary?.trim() ||
      !body.story?.trim() ||
      !body.townId?.trim() ||
      !body.author?.trim()
    ) {
      res.status(400).json({
        error: "Wypełnij nagłówek, krótki opis, treść opowieści, miejscowość oraz autora.",
      });
      return;
    }

    const newEntry: StoredTownEntry = {
      id: `entry_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      headline: body.headline.trim(),
      summary: body.summary.trim(),
      story: body.story.trim(),
      townId: body.townId.trim(),
      townName: body.townName?.trim() || body.townId.trim(),
      author: body.author.trim(),
      createdAt: new Date().toISOString(),
    };

    const existing = readJsonArray<StoredTownEntry>(TOWN_ENTRIES_FILE);
    writeJsonArray(TOWN_ENTRIES_FILE, [newEntry, ...existing]);
    res.status(201).json({ entry: newEntry });
  });

  app.delete("/api/town-entries/:id", (req, res) => {
    const { id } = req.params;
    const existing = readJsonArray<StoredTownEntry>(TOWN_ENTRIES_FILE);
    const filtered = existing.filter((item) => item.id !== id);
    if (filtered.length === existing.length) {
      res.status(404).json({ error: "Nie znaleziono wpisu." });
      return;
    }
    writeJsonArray(TOWN_ENTRIES_FILE, filtered);
    res.json({ deleted: id });
  });

  if (isProd) {
    const distDir = path.resolve(__dirname, "dist");
    app.use(express.static(distDir));
    app.get("/{*splat}", (_req, res) => {
      res.sendFile(path.join(distDir, "index.html"));
    });
  } else {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  }

  app.listen(port, "0.0.0.0", () => {
    console.log(`Przewodnik po Ponidziu server listening on http://0.0.0.0:${port}`);
  });
}

startServer().catch((err) => {
  console.error("Failed to start server:", err);
  process.exit(1);
});

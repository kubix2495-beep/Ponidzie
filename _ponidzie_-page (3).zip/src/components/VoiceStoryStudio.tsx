import {
  ChangeEvent,
  DragEvent,
  FormEvent,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import {
  AudioLines,
  Check,
  FileAudio,
  Loader2,
  Mic,
  Pause,
  Play,
  RotateCcw,
  Square,
  Trash2,
  Upload,
} from "lucide-react";
import { PONIDZIE_TOWNS } from "../data/ponidzieData";
import { VoiceStory, deleteStory, saveStory } from "../services/storyStorage";
import { autoCorrectProfanity } from "../utils/profanityFilter";

interface VoiceStoryStudioProps {
  stories: VoiceStory[];
  isLoadingStories: boolean;
  preselectedTownId: string;
  onStoriesChange: (stories: VoiceStory[]) => void;
}

function formatSeconds(totalSeconds: number): string {
  const safe = Math.max(0, Math.floor(totalSeconds));
  const mins = Math.floor(safe / 60);
  const secs = safe % 60;
  return `${String(mins).padStart(2, "0")}:${String(secs).padStart(2, "0")}`;
}

function formatDatePl(iso: string): string {
  try {
    return new Intl.DateTimeFormat("pl-PL", {
      day: "numeric",
      month: "long",
      year: "numeric",
    }).format(new Date(iso));
  } catch {
    return iso;
  }
}

function readBlobAsDataUrl(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      if (typeof reader.result === "string") {
        resolve(reader.result);
      } else {
        reject(new Error("Nie udało się odczytać pliku audio."));
      }
    };
    reader.onerror = () => reject(new Error("Błąd odczytu danych audio."));
    reader.readAsDataURL(blob);
  });
}

function getAudioDurationFromUrl(url: string): Promise<number> {
  return new Promise((resolve) => {
    const audio = new Audio();
    audio.preload = "metadata";
    audio.onloadedmetadata = () => {
      if (Number.isFinite(audio.duration)) {
        resolve(Math.round(audio.duration));
      } else {
        resolve(0);
      }
    };
    audio.onerror = () => resolve(0);
    audio.src = url;
  });
}

export default function VoiceStoryStudio({
  stories,
  isLoadingStories,
  preselectedTownId,
  onStoriesChange,
}: VoiceStoryStudioProps) {
  const [inputMode, setInputMode] = useState<"record" | "upload">("record");
  const [townId, setTownId] = useState<string>(preselectedTownId || "busko-zdroj");
  const [author, setAuthor] = useState<string>("");
  const [title, setTitle] = useState<string>("");
  const [note, setNote] = useState<string>("");

  const [isRecording, setIsRecording] = useState<boolean>(false);
  const [recordingSeconds, setRecordingSeconds] = useState<number>(0);
  const [audioDataUrl, setAudioDataUrl] = useState<string>("");
  const [audioMimeType, setAudioMimeType] = useState<string>("audio/webm");
  const [audioDuration, setAudioDuration] = useState<number>(0);
  const [uploadedFileName, setUploadedFileName] = useState<string>("");
  const [waveformBars, setWaveformBars] = useState<number[]>(Array(24).fill(12));

  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string>("");
  const [successMessage, setSuccessMessage] = useState<string>("");

  const [archiveFilterTown, setArchiveFilterTown] = useState<string>("all");
  const [playingId, setPlayingId] = useState<string | null>(null);
  const [playProgress, setPlayProgress] = useState<Record<string, number>>({});
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<number | null>(null);
  const animFrameRef = useRef<number | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const playerAudioRef = useRef<HTMLAudioElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (preselectedTownId) {
      setTownId(preselectedTownId);
    }
  }, [preselectedTownId]);

  useEffect(() => {
    return () => {
      if (timerRef.current) window.clearInterval(timerRef.current);
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((t) => t.stop());
      }
      if (audioCtxRef.current && audioCtxRef.current.state !== "closed") {
        audioCtxRef.current.close().catch(() => {});
      }
      if (playerAudioRef.current) {
        playerAudioRef.current.pause();
      }
    };
  }, []);

  const townOptions = useMemo(
    () => [
      ...PONIDZIE_TOWNS.map((t) => ({ id: t.id, name: t.name })),
      { id: "ponidzie", name: "Całe Ponidzie" },
    ],
    []
  );

  const selectedTownName =
    townOptions.find((t) => t.id === townId)?.name ?? "Całe Ponidzie";

  const resetCapture = () => {
    setAudioDataUrl("");
    setUploadedFileName("");
    setAudioDuration(0);
    setRecordingSeconds(0);
    setErrorMessage("");
    setSuccessMessage("");
    setWaveformBars(Array(24).fill(12));
  };

  const stopStreamResources = () => {
    if (timerRef.current) {
      window.clearInterval(timerRef.current);
      timerRef.current = null;
    }
    if (animFrameRef.current) {
      cancelAnimationFrame(animFrameRef.current);
      animFrameRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    if (audioCtxRef.current && audioCtxRef.current.state !== "closed") {
      audioCtxRef.current.close().catch(() => {});
      audioCtxRef.current = null;
    }
  };

  const startRecording = async () => {
    setErrorMessage("");
    setSuccessMessage("");

    if (!navigator.mediaDevices?.getUserMedia) {
      setErrorMessage(
        "Twoja przeglądarka nie obsługuje nagrywania z mikrofonu. Użyj opcji wgrania pliku audio."
      );
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;

      const preferredTypes = [
        "audio/webm;codecs=opus",
        "audio/webm",
        "audio/mp4",
        "audio/ogg",
      ];
      const supportedMime =
        preferredTypes.find((type) => MediaRecorder.isTypeSupported(type)) || "";

      const recorderOptions: MediaRecorderOptions = {
        audioBitsPerSecond: 48000,
        ...(supportedMime ? { mimeType: supportedMime } : {}),
      };
      const recorder = new MediaRecorder(stream, recorderOptions);

      mediaRecorderRef.current = recorder;
      chunksRef.current = [];

      const AudioContextCtor =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioContextCtor) {
        const ctx = new AudioContextCtor();
        audioCtxRef.current = ctx;
        const source = ctx.createMediaStreamSource(stream);
        const analyser = ctx.createAnalyser();
        analyser.fftSize = 64;
        source.connect(analyser);
        const dataArray = new Uint8Array(analyser.frequencyBinCount);

        const updateBars = () => {
          analyser.getByteFrequencyData(dataArray);
          const nextBars = Array.from({ length: 24 }, (_, idx) => {
            const val = dataArray[idx % dataArray.length] ?? 0;
            return Math.max(10, Math.min(100, Math.round((val / 255) * 100)));
          });
          setWaveformBars(nextBars);
          animFrameRef.current = requestAnimationFrame(updateBars);
        };
        updateBars();
      }

      recorder.ondataavailable = (event) => {
        if (event.data && event.data.size > 0) {
          chunksRef.current.push(event.data);
        }
      };

      let startedAt = Date.now();
      recorder.onstop = async () => {
        const elapsed = Math.max(1, Math.round((Date.now() - startedAt) / 1000));
        const finalMime = recorder.mimeType || supportedMime || "audio/webm";
        const blob = new Blob(chunksRef.current, { type: finalMime });
        stopStreamResources();

        try {
          const dataUrl = await readBlobAsDataUrl(blob);
          setAudioDataUrl(dataUrl);
          setAudioMimeType(finalMime);
          setAudioDuration(elapsed);
          setUploadedFileName("Nagranie mikrofonowe");
        } catch (err) {
          setErrorMessage(
            err instanceof Error ? err.message : "Nie udało się zapisać nagrania."
          );
        }
      };

      setRecordingSeconds(0);
      setIsRecording(true);
      startedAt = Date.now();
      recorder.start(250);

      timerRef.current = window.setInterval(() => {
        setRecordingSeconds((prev) => prev + 1);
      }, 1000);
    } catch {
      setErrorMessage(
        "Brak dostępu do mikrofonu. Zezwól przeglądarce na dostęp do mikrofonu lub wgraj plik audio."
      );
      stopStreamResources();
      setIsRecording(false);
    }
  };

  const stopRecording = () => {
    setIsRecording(false);
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== "inactive") {
      mediaRecorderRef.current.stop();
    } else {
      stopStreamResources();
    }
  };

  const handleAudioFile = async (file: File) => {
    setErrorMessage("");
    setSuccessMessage("");

    const maxBytes = 15 * 1024 * 1024;
    if (file.size > maxBytes) {
      setErrorMessage("Plik jest większy niż 15 MB. Wybierz krótsze nagranie.");
      return;
    }

    if (!file.type.startsWith("audio/") && !/\.(mp3|wav|m4a|ogg|webm)$/i.test(file.name)) {
      setErrorMessage("Wybierz poprawny plik audio (MP3, WAV, M4A, OGG lub WebM).");
      return;
    }

    try {
      const dataUrl = await readBlobAsDataUrl(file);
      const duration = await getAudioDurationFromUrl(dataUrl);
      setAudioDataUrl(dataUrl);
      setAudioMimeType(file.type || "audio/mpeg");
      setAudioDuration(duration);
      setUploadedFileName(file.name);
    } catch (err) {
      setErrorMessage(
        err instanceof Error ? err.message : "Nie udało się wczytać pliku audio."
      );
    }
  };

  const handleFileInputChange = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      handleAudioFile(file);
    }
  };

  const handleDrop = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    if (file) {
      handleAudioFile(file);
    }
  };

  const handlePublishStory = async (e: FormEvent) => {
    e.preventDefault();
    setErrorMessage("");
    setSuccessMessage("");

    if (!audioDataUrl) {
      setErrorMessage("Nagraj swój głos lub wgraj plik audio przed zapisaniem opowieści.");
      return;
    }
    if (!title.trim() || !author.trim()) {
      setErrorMessage("Wpisz tytuł opowieści oraz imię lub podpis autora.");
      return;
    }

    const cleanTitle = autoCorrectProfanity(title.trim()).cleanedText;
    const cleanAuthor = autoCorrectProfanity(author.trim()).cleanedText;
    const cleanNote = autoCorrectProfanity(note.trim()).cleanedText;

    setIsSaving(true);
    try {
      const created = await saveStory({
        title: cleanTitle,
        author: cleanAuthor,
        townId,
        townName: selectedTownName,
        note: cleanNote,
        audioDataUrl,
        mimeType: audioMimeType,
        durationSeconds: audioDuration,
      });

      onStoriesChange([created, ...stories]);
      setTitle("");
      setAuthor("");
      setNote("");
      resetCapture();
      setSuccessMessage("Nagranie głosowe zostało zapisane w archiwum Ponidzia.");
    } catch (err) {
      setErrorMessage(
        err instanceof Error ? err.message : "Nie udało się zapisać nagrania."
      );
    } finally {
      setIsSaving(false);
    }
  };

  const handleTogglePlay = (story: VoiceStory) => {
    if (playingId === story.id && playerAudioRef.current) {
      playerAudioRef.current.pause();
      setPlayingId(null);
      return;
    }

    if (playerAudioRef.current) {
      playerAudioRef.current.pause();
    }

    const audio = new Audio(story.audioDataUrl);
    playerAudioRef.current = audio;

    audio.ontimeupdate = () => {
      if (audio.duration && Number.isFinite(audio.duration)) {
        setPlayProgress((prev) => ({
          ...prev,
          [story.id]: Math.round((audio.currentTime / audio.duration) * 100),
        }));
      }
    };

    audio.onended = () => {
      setPlayingId(null);
      setPlayProgress((prev) => ({ ...prev, [story.id]: 0 }));
    };

    audio.play().catch(() => {
      setErrorMessage("Nie udało się odtworzyć tego nagrania w przeglądarce.");
    });
    setPlayingId(story.id);
  };

  const handleDelete = async (id: string) => {
    if (playingId === id && playerAudioRef.current) {
      playerAudioRef.current.pause();
      setPlayingId(null);
    }
    await deleteStory(id);
    onStoriesChange(stories.filter((s) => s.id !== id));
    setConfirmDeleteId(null);
  };

  const filteredStories = useMemo(() => {
    if (archiveFilterTown === "all") return stories;
    return stories.filter((s) => s.townId === archiveFilterTown);
  }, [stories, archiveFilterTown]);

  return (
    <section id="opowiesci" className="py-20 lg:py-28">
      <div className="max-w-7xl mx-auto px-6 lg:px-10">
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 mb-12">
          <div>
            <p className="text-xs uppercase tracking-[0.18em] text-[#57534E] dark:text-[#A8A29E] font-medium mb-3">
              03 · Żywe archiwum pamięci
            </p>
            <h2 className="font-serif text-3xl sm:text-4xl font-semibold text-[#1C1917] dark:text-[#F2F0EB] tracking-tight text-balance">
              Nagraj głos lub wgraj opowieść audio z Ponidzia
            </h2>
          </div>
          <p className="text-sm sm:text-base text-[#57534E] dark:text-[#A8A29E] max-w-md leading-relaxed">
            Nagraj wspomnienie mikrofonem prosto w przeglądarce albo wgraj gotowy plik audio
            (MP3, WAV, M4A, OGG), aby zachować je w archiwum przewodnika.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
          {/* Left 5 columns: Voice Recorder & Audio Upload */}
          <div className="lg:col-span-5 bg-white dark:bg-[#1B1B18] border border-[#E5E2DC] dark:border-[#2E2D28] rounded-xl p-6 sm:p-8">
            <div className="flex items-center justify-between gap-4 pb-5 border-b border-[#ECE9E2] dark:border-[#2E2D28]">
              <h3 className="font-serif text-xl font-semibold text-[#1C1917] dark:text-[#F2F0EB]">
                Studio nagrań
              </h3>
              <div className="flex items-center gap-1 p-1 bg-[#EFECE5] dark:bg-[#22211C] rounded-lg">
                <button
                  type="button"
                  onClick={() => setInputMode("record")}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                    inputMode === "record"
                      ? "bg-white dark:bg-[#131311] text-[#1C1917] dark:text-[#F2F0EB] shadow-xs"
                      : "text-[#57534E] dark:text-[#A8A29E] hover:text-[#1C1917] dark:hover:text-[#F2F0EB]"
                  }`}
                >
                  Mikrofon
                </button>
                <button
                  type="button"
                  onClick={() => setInputMode("upload")}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                    inputMode === "upload"
                      ? "bg-white dark:bg-[#131311] text-[#1C1917] dark:text-[#F2F0EB] shadow-xs"
                      : "text-[#57534E] dark:text-[#A8A29E] hover:text-[#1C1917] dark:hover:text-[#F2F0EB]"
                  }`}
                >
                  Plik audio
                </button>
              </div>
            </div>

            <form onSubmit={handlePublishStory} className="mt-6 space-y-5">
              <div>
                <label
                  htmlFor="story-town"
                  className="block text-xs uppercase tracking-[0.12em] text-[#57534E] dark:text-[#A8A29E] font-medium mb-2"
                >
                  Miejscowość na szlaku
                </label>
                <select
                  id="story-town"
                  value={townId}
                  onChange={(e) => setTownId(e.target.value)}
                  className="w-full rounded-lg border border-[#D6D3CB] dark:border-[#3A3932] bg-[#FBFBF9] dark:bg-[#131311] px-3.5 py-2.5 text-sm text-[#1C1917] dark:text-[#F2F0EB] focus:outline-none focus:ring-2 focus:ring-[#1E4D3B] dark:focus:ring-[#6EE7B7]"
                >
                  {townOptions.map((opt) => (
                    <option key={opt.id} value={opt.id}>
                      {opt.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label
                    htmlFor="story-author"
                    className="block text-xs uppercase tracking-[0.12em] text-[#57534E] dark:text-[#A8A29E] font-medium mb-2"
                  >
                    Autor / Głos
                  </label>
                  <input
                    id="story-author"
                    type="text"
                    value={author}
                    onChange={(e) => setAuthor(e.target.value)}
                    placeholder="np. Tata, Jan z Buska"
                    className="w-full rounded-lg border border-[#D6D3CB] dark:border-[#3A3932] bg-[#FBFBF9] dark:bg-[#131311] px-3.5 py-2.5 text-sm text-[#1C1917] dark:text-[#F2F0EB] placeholder:text-[#A8A29E] dark:placeholder:text-[#78716C] focus:outline-none focus:ring-2 focus:ring-[#1E4D3B] dark:focus:ring-[#6EE7B7]"
                  />
                </div>
                <div>
                  <label
                    htmlFor="story-title"
                    className="block text-xs uppercase tracking-[0.12em] text-[#57534E] dark:text-[#A8A29E] font-medium mb-2"
                  >
                    Tytuł nagrania
                  </label>
                  <input
                    id="story-title"
                    type="text"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="np. Dawne spacery nad Nidą"
                    className="w-full rounded-lg border border-[#D6D3CB] dark:border-[#3A3932] bg-[#FBFBF9] dark:bg-[#131311] px-3.5 py-2.5 text-sm text-[#1C1917] dark:text-[#F2F0EB] placeholder:text-[#A8A29E] dark:placeholder:text-[#78716C] focus:outline-none focus:ring-2 focus:ring-[#1E4D3B] dark:focus:ring-[#6EE7B7]"
                  />
                </div>
              </div>

              {/* Audio Capture Box */}
              <div className="rounded-xl border border-[#E2DFD7] dark:border-[#2E2D28] bg-[#F8F7F4] dark:bg-[#141412] p-5">
                {inputMode === "record" ? (
                  <div>
                    <div className="flex items-center justify-between mb-4">
                      <span className="text-xs font-medium text-[#57534E] dark:text-[#A8A29E]">
                        {isRecording
                          ? "Nagrywanie trwa..."
                          : audioDataUrl
                          ? "Nagranie gotowe do zapisu"
                          : "Naciśnij przycisk, aby rozpocząć opowieść"}
                      </span>
                      <span className="font-mono text-sm font-medium text-[#1C1917] dark:text-[#F2F0EB] tabular-nums">
                        {formatSeconds(isRecording ? recordingSeconds : audioDuration)}
                      </span>
                    </div>

                    <div
                      aria-hidden="true"
                      className="h-14 flex items-center justify-between gap-1 px-2 mb-4 bg-white dark:bg-[#1B1B18] rounded-lg border border-[#E5E2DC] dark:border-[#2E2D28]"
                    >
                      {waveformBars.map((heightPct, i) => (
                        <div
                          key={i}
                          className={`w-1.5 rounded-full transition-all duration-100 ${
                            isRecording
                              ? "bg-[#1E4D3B] dark:bg-[#6EE7B7]"
                              : "bg-[#C7C2B8] dark:bg-[#44403C]"
                          }`}
                          style={{ height: `${Math.max(12, heightPct)}%` }}
                        />
                      ))}
                    </div>

                    <div className="flex flex-wrap items-center gap-3">
                      {!isRecording ? (
                        <button
                          type="button"
                          onClick={startRecording}
                          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-[#1E4D3B] dark:bg-[#2A6F55] text-white text-sm font-medium hover:bg-[#173B2D] dark:hover:bg-[#235C46] transition-colors whitespace-nowrap"
                        >
                          <Mic className="w-4 h-4" />
                          <span>{audioDataUrl ? "Nagraj ponownie" : "Rozpocznij nagrywanie"}</span>
                        </button>
                      ) : (
                        <button
                          type="button"
                          onClick={stopRecording}
                          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-[#991B1B] text-white text-sm font-medium hover:bg-[#7F1D1D] transition-colors whitespace-nowrap"
                        >
                          <Square className="w-3.5 h-3.5 fill-current" />
                          <span>Zatrzymaj nagranie</span>
                        </button>
                      )}

                      {audioDataUrl && !isRecording && (
                        <button
                          type="button"
                          onClick={resetCapture}
                          className="inline-flex items-center gap-1.5 px-3 py-2.5 rounded-lg border border-[#D6D3CB] dark:border-[#3A3932] text-xs font-medium text-[#44403C] dark:text-[#D6D3CB] hover:bg-white dark:hover:bg-[#262520] transition-colors whitespace-nowrap"
                        >
                          <RotateCcw className="w-3.5 h-3.5" />
                          <span>Wyczyść</span>
                        </button>
                      )}
                    </div>
                  </div>
                ) : (
                  <div
                    onDragOver={(e) => e.preventDefault()}
                    onDrop={handleDrop}
                    className="text-center py-4"
                  >
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="audio/*,.mp3,.wav,.m4a,.ogg,.webm"
                      onChange={handleFileInputChange}
                      className="sr-only"
                    />
                    <FileAudio className="w-7 h-7 mx-auto mb-2.5 text-[#1E4D3B] dark:text-[#6EE7B7]" />
                    <p className="text-sm font-medium text-[#1C1917] dark:text-[#F2F0EB]">
                      {uploadedFileName && uploadedFileName !== "Nagranie mikrofonowe"
                        ? uploadedFileName
                        : "Przeciągnij plik audio lub wybierz z dysku"}
                    </p>
                    <p className="text-xs text-[#78716C] dark:text-[#A8A29E] mt-1 mb-4">
                      Obsługiwane formaty: MP3, WAV, M4A, OGG, WebM (do 15 MB)
                    </p>
                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg border border-[#D6D3CB] dark:border-[#3A3932] bg-white dark:bg-[#1B1B18] text-sm font-medium text-[#1C1917] dark:text-[#F2F0EB] hover:bg-[#F4F2ED] dark:hover:bg-[#262520] transition-colors whitespace-nowrap"
                    >
                      <Upload className="w-4 h-4 text-[#1E4D3B] dark:text-[#6EE7B7]" />
                      <span>Wybierz plik audio</span>
                    </button>
                  </div>
                )}

                {audioDataUrl && !isRecording && (
                  <div className="mt-4 pt-4 border-t border-[#E5E2DC] dark:border-[#2E2D28]">
                    <audio controls src={audioDataUrl} className="w-full h-10" />
                  </div>
                )}
              </div>

              <div>
                <label
                  htmlFor="story-note"
                  className="block text-xs uppercase tracking-[0.12em] text-[#57534E] dark:text-[#A8A29E] font-medium mb-2"
                >
                  Krótka notatka do nagrania (opcjonalnie)
                </label>
                <textarea
                  id="story-note"
                  rows={3}
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  placeholder="Możesz dopisać kilka słów o tym, czego dotyczy nagranie..."
                  className="w-full rounded-lg border border-[#D6D3CB] dark:border-[#3A3932] bg-[#FBFBF9] dark:bg-[#131311] px-3.5 py-2.5 text-sm text-[#1C1917] dark:text-[#F2F0EB] leading-relaxed placeholder:text-[#A8A29E] dark:placeholder:text-[#78716C] focus:outline-none focus:ring-2 focus:ring-[#1E4D3B] dark:focus:ring-[#6EE7B7]"
                />
              </div>

              {errorMessage && (
                <div
                  role="alert"
                  className="rounded-lg border border-[#FCA5A5] dark:border-[#7F1D1D] bg-[#FEF2F2] dark:bg-[#450A0A]/50 px-4 py-3 text-xs sm:text-sm text-[#991B1B] dark:text-[#FECACA]"
                >
                  {errorMessage}
                </div>
              )}

              {successMessage && (
                <div
                  role="status"
                  className="rounded-lg border border-[#BBF7D0] dark:border-[#166534] bg-[#F0FDF4] dark:bg-[#052E16]/50 px-4 py-3 text-xs sm:text-sm text-[#166534] dark:text-[#BBF7D0] flex items-center gap-2"
                >
                  <Check className="w-4 h-4 shrink-0" />
                  <span>{successMessage}</span>
                </div>
              )}

              <button
                type="submit"
                disabled={isRecording || isSaving || !audioDataUrl}
                className="w-full inline-flex items-center justify-center gap-2 px-5 py-3 rounded-lg bg-[#1E4D3B] dark:bg-[#2A6F55] text-white text-sm font-medium hover:bg-[#173B2D] dark:hover:bg-[#235C46] disabled:opacity-50 disabled:cursor-not-allowed transition-colors whitespace-nowrap"
              >
                {isSaving ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Zapisywanie w archiwum...</span>
                  </>
                ) : (
                  <span>Zapisz nagranie w archiwum</span>
                )}
              </button>
            </form>
          </div>

          {/* Right 7 columns: Living Voice Archive */}
          <div className="lg:col-span-7">
            <div className="flex flex-wrap items-center justify-between gap-4 pb-5 border-b border-[#E5E2DC] dark:border-[#2B2A24] mb-6">
              <div>
                <h3 className="font-serif text-2xl font-semibold text-[#1C1917] dark:text-[#F2F0EB]">
                  Nagrane opowieści ({filteredStories.length})
                </h3>
                <p className="text-xs text-[#78716C] dark:text-[#A8A29E] mt-1">
                  Odsłuchaj wspomnienia mieszkańców i podróżników znad Nidy.
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-1 p-1 bg-[#EFECE5] dark:bg-[#22211C] rounded-lg border border-[#E2DFD7] dark:border-[#323029]">
                <button
                  type="button"
                  onClick={() => setArchiveFilterTown("all")}
                  className={`px-2.5 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                    archiveFilterTown === "all"
                      ? "bg-white dark:bg-[#131311] text-[#1C1917] dark:text-[#F2F0EB] shadow-xs"
                      : "text-[#57534E] dark:text-[#A8A29E] hover:text-[#1C1917] dark:hover:text-[#F2F0EB]"
                  }`}
                >
                  Wszystkie
                </button>
                {PONIDZIE_TOWNS.map((t) => (
                  <button
                    key={t.id}
                    type="button"
                    onClick={() => setArchiveFilterTown(t.id)}
                    className={`px-2.5 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                      archiveFilterTown === t.id
                        ? "bg-white dark:bg-[#131311] text-[#1C1917] dark:text-[#F2F0EB] shadow-xs"
                        : "text-[#57534E] dark:text-[#A8A29E] hover:text-[#1C1917] dark:hover:text-[#F2F0EB]"
                    }`}
                  >
                    {t.name}
                  </button>
                ))}
              </div>
            </div>

            {isLoadingStories ? (
              <div className="bg-white dark:bg-[#1B1B18] border border-[#E5E2DC] dark:border-[#2E2D28] rounded-xl p-10 text-center text-sm text-[#57534E] dark:text-[#A8A29E]">
                <Loader2 className="w-5 h-5 animate-spin mx-auto mb-3 text-[#1E4D3B] dark:text-[#6EE7B7]" />
                <span>Wczytywanie archiwum opowieści...</span>
              </div>
            ) : filteredStories.length === 0 ? (
              <div className="bg-white dark:bg-[#1B1B18] border border-[#E5E2DC] dark:border-[#2E2D28] rounded-xl p-10 sm:p-12 text-center">
                <AudioLines className="w-8 h-8 mx-auto mb-3 text-[#1E4D3B] dark:text-[#6EE7B7]" />
                <h4 className="font-serif text-xl font-semibold text-[#1C1917] dark:text-[#F2F0EB] mb-2">
                  {archiveFilterTown === "all"
                    ? "Archiwum czeka na pierwszą opowieść"
                    : "Brak nagrań dla tej miejscowości"}
                </h4>
                <p className="text-sm text-[#57534E] dark:text-[#A8A29E] max-w-md mx-auto leading-relaxed">
                  Nagraj wspomnienie Taty lub wgraj plik audio w studiu obok, a pojawi się ono od
                  razu z odtwarzaczem w archiwum.
                </p>
              </div>
            ) : (
              <div className="space-y-5">
                {filteredStories.map((story) => {
                  const isPlaying = playingId === story.id;
                  const progress = playProgress[story.id] || 0;
                  const storyNote = story.note || story.transcript;

                  return (
                    <article
                      key={story.id}
                      className="bg-white dark:bg-[#1B1B18] border border-[#E5E2DC] dark:border-[#2E2D28] rounded-xl p-6 sm:p-7"
                    >
                      <div className="flex flex-wrap items-center justify-between gap-3 text-xs text-[#57534E] dark:text-[#A8A29E] mb-3">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="font-medium text-[#1E4D3B] dark:text-[#6EE7B7]">
                            {story.townName}
                          </span>
                          <span aria-hidden="true">·</span>
                          <span>{story.author}</span>
                          <span aria-hidden="true">·</span>
                          <span>{formatDatePl(story.createdAt)}</span>
                        </div>

                        {confirmDeleteId === story.id ? (
                          <div className="flex items-center gap-2">
                            <button
                              type="button"
                              onClick={() => handleDelete(story.id)}
                              className="text-xs font-medium text-[#991B1B] dark:text-[#FCA5A5] hover:underline"
                            >
                              Potwierdź usunięcie
                            </button>
                            <button
                              type="button"
                              onClick={() => setConfirmDeleteId(null)}
                              className="text-xs text-[#78716C] dark:text-[#A8A29E] hover:underline"
                            >
                              Anuluj
                            </button>
                          </div>
                        ) : (
                          <button
                            type="button"
                            aria-label={`Usuń opowieść ${story.title}`}
                            onClick={() => setConfirmDeleteId(story.id)}
                            className="p-1.5 rounded-md text-[#78716C] dark:text-[#A8A29E] hover:text-[#991B1B] dark:hover:text-[#FCA5A5] hover:bg-[#FEF2F2] dark:hover:bg-[#450A0A]/40 transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>

                      <h4 className="font-serif text-2xl font-semibold text-[#1C1917] dark:text-[#F2F0EB] mb-4">
                        {story.title}
                      </h4>

                      <div className="flex items-center gap-4 p-3.5 rounded-lg bg-[#F8F7F4] dark:bg-[#141412] border border-[#ECE9E2] dark:border-[#2E2D28]">
                        <button
                          type="button"
                          aria-label={isPlaying ? "Wstrzymaj nagranie" : "Odtwórz nagranie"}
                          onClick={() => handleTogglePlay(story)}
                          className="w-10 h-10 rounded-full bg-[#1E4D3B] dark:bg-[#2A6F55] text-white flex items-center justify-center shrink-0 hover:bg-[#173B2D] dark:hover:bg-[#235C46] transition-colors"
                        >
                          {isPlaying ? (
                            <Pause className="w-4 h-4" />
                          ) : (
                            <Play className="w-4 h-4 ml-0.5" />
                          )}
                        </button>
                        <div className="flex-1 min-w-0">
                          <div className="h-1.5 w-full bg-[#E2DFD7] dark:bg-[#2E2D28] rounded-full overflow-hidden">
                            <div
                              className="h-full bg-[#1E4D3B] dark:bg-[#6EE7B7] transition-all duration-150"
                              style={{ width: `${progress}%` }}
                            />
                          </div>
                        </div>
                        <span className="font-mono text-xs text-[#57534E] dark:text-[#A8A29E] tabular-nums shrink-0">
                          {story.durationSeconds > 0
                            ? formatSeconds(story.durationSeconds)
                            : "Audio"}
                        </span>
                      </div>

                      {storyNote && (
                        <p className="mt-4 text-[15px] text-[#292524] dark:text-[#E7E5E4] leading-[1.7] whitespace-pre-line max-w-prose">
                          {storyNote}
                        </p>
                      )}
                    </article>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}

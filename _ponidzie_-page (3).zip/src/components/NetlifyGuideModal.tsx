import { X } from "lucide-react";

interface NetlifyGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function NetlifyGuideModal({ isOpen, onClose }: NetlifyGuideModalProps) {
  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="netlify-guide-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/55 backdrop-blur-[2px]"
      onClick={onClose}
    >
      <div
        className="bg-white dark:bg-[#1B1B18] border border-[#E5E2DC] dark:border-[#2E2D28] rounded-xl max-w-xl w-full p-6 sm:p-8 shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-4 pb-4 border-b border-[#ECE9E2] dark:border-[#2E2D28]">
          <div>
            <p className="text-xs uppercase tracking-[0.16em] text-[#1E4D3B] dark:text-[#6EE7B7] font-medium mb-1">
              Wdrożenie statyczne
            </p>
            <h3
              id="netlify-guide-title"
              className="font-serif text-2xl font-semibold text-[#1C1917] dark:text-[#F2F0EB]"
            >
              Konfiguracja w Netlify
            </h3>
          </div>
          <button
            type="button"
            aria-label="Zamknij okno"
            onClick={onClose}
            className="p-2 rounded-lg text-[#57534E] dark:text-[#A8A29E] hover:text-[#1C1917] dark:hover:text-[#F2F0EB] hover:bg-[#F4F2ED] dark:hover:bg-[#262520] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="mt-5 space-y-4 text-sm text-[#44403C] dark:text-[#D6D3CB] leading-relaxed">
          <p>
            Strona jest gotowa do prostego wdrożenia na Netlify bez żadnych dodatkowych kluczy API
            ani zmiennych środowiskowych.
          </p>

          <ol className="space-y-3 list-decimal list-inside">
            <li>
              Plik <span className="font-mono text-[#1C1917] dark:text-[#F2F0EB]">netlify.toml</span>{" "}
              automatycznie ustawia polecenie budowania{" "}
              <span className="font-mono text-[#1C1917] dark:text-[#F2F0EB]">npm run build</span>{" "}
              oraz katalog wynikowy{" "}
              <span className="font-mono text-[#1C1917] dark:text-[#F2F0EB]">dist</span>.
            </li>
            <li>
              Po połączeniu repozytorium w Netlify wystarczy uruchomić wdrożenie — wszystkie
              nagrania audio i dodane treści do miast zapisują się bezpiecznie w pamięci
              przeglądarki (IndexedDB).
            </li>
          </ol>
        </div>

        <div className="mt-7 pt-5 border-t border-[#ECE9E2] dark:border-[#2E2D28] flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-lg bg-[#1E4D3B] dark:bg-[#2A6F55] text-white text-sm font-medium hover:bg-[#173B2D] dark:hover:bg-[#235C46] transition-colors"
          >
            Rozumiem
          </button>
        </div>
      </div>
    </div>
  );
}
